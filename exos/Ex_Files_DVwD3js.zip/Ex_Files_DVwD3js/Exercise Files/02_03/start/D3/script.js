d3.select('#chart .item:nth-child(3)')
  .remove()

require 'rails_helper'

describe MoviesHelper, type: :helper do
end

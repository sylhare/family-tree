'use strict';
// Express: http://localhost:3000/api/v0
// Flask: http://localhost:5000/api/v0

module.exports = {
  apiBaseURL: 'http://localhost:3000/api/v0' 
};

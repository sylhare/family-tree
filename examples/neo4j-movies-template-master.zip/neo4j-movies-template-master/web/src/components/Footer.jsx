import React from 'react';

export default class Footer extends React.Component {
  render() {
    return (
      <footer className="nt-app-footer">
        Such Footer
      </footer>
    );
  }
}

Footer.displayName = 'Footer';

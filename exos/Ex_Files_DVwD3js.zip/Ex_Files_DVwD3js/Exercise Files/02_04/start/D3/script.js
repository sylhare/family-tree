d3.selectAll('.item:nth-child(3)')
  .style({
    'background': '#268BD2',
    'padding': '10px',
    'margin' : '5px',
    'color' : '#EEE8D5'
  })